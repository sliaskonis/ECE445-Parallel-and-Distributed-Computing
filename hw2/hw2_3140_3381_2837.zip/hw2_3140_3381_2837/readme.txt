Compile:
    make
Run: Executables created inside ./bin/
    ./bin/<exec_name>